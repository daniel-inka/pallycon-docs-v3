# Inka Forensic Watermark

Inka Forensic Watermark consists of the following modules:
- FMembedder: Creates two media files that are embedded with '0' or '1' respectively. For example, it creates 'A_0.mp4' and 'A_1.mp4' when the input media is 'A.mp4'. The two files must be mixed in order to embed a user-specific-information.
- Stream Mixer: A server-side mixer that mixes two streams to a single stream for a specific user or device. It mixes stream '0' and stream '1' according to binary format of the user-specific-information, because the information can be represented in binary format. You can use our PallyCon Packager to create DASH or HLS stream from a media file.
- Sample Mixer: A client-side mixer that mixes two mp4 files to a single mp4 file for evaluating. The concept of Sample mixer is the same as Stream Mixer except the source and target media type.
- FMdetector: Detects embedded information from a media file.

This distribution includes only the following modules:
- FMembedder
- Sample Mixer

Please contact us for a description of other modules:
- Stream Mixer
- FMdetector

---

## Execution environment

The following environment is required to run FMembedder:
- Hardware
  - CPU: Intel® only
  - RAM: 8GB or above
  - GPU: [NVIDIA Graphic card](https://developer.nvidia.com/video-encode-decode-gpu-support-matrix) which supports video encoding and decoding
- Software
  - Ubuntu Server 16.04 LTS
  - Intel® IPP (Integrated Performance Primitives) 2018
  - NVIDIA CUDA Toolkit 9.1 (for using NVIDIA HW Accelation)
  - Dependency libraries


## Install Intel® IPP 2018

Follow [Installation Intel® IPP 2018 Guide](Readme_intel_ipp.md)


## Install NVIDIA CUDA Toolkit 9.1

Follow [Installation NVIDIA CUDA Toolkit 9.1](Readme_nvidia_cuda.md)


## NVIDIA Video Encode and Decode GPU Support Matrix

- https://developer.nvidia.com/video-encode-decode-gpu-support-matrix
- AWS GPU instance performance:
  - Geforce GTX1050(Desktop, Pascal) << P2(Tesla K80) << P3(Tesla V100), G3(Tesla M60)
  - Select the AWS instance(GPU) for your application. We recommend using either P3 or G3 if you plan to use it for SaaS.


## Install dependency libraries
```sh
$ sudo apt update
$ sudo apt install -y \
		libbz2-dev \
		zlib1g-dev \
		libva-dev \
		libvdpau-dev \
		libssl-dev
```

## Usages

- FMembedder

  - Mandotory parameters:
    - Input media filename
      - e.g.) -i ~/demo/input.mp4
    - Ouput media filename
      - e.g.) -o ~/demo/output.mp4
      - ~/demo/output_0.mp4 and ~/demo/output_1.mp4 will be created.
    - Access-key
      - e.g.) --access_key ACCESSKEY_BLAHBLAH
      - Please contact us to get the Access-key.
  - If you need some help about input parameters, run it with '-h' option.
    ```sh
    $ FMembedder -h
    ```
  - You shoult set LD_LIBRARY_PATH if you have a trouble with shared library path. Please refer FMembedder.sh.

  Usage 1: Using NVIDIA HW accelation encoder (nvenc)
  - using -n option
  ```sh
  $ FMembedder -i ~/demo/input.mp4 -o ~/demo/output.mp4 -n --access_key ACCESSKEY_BLAHBLAH
  ```

  Usage 2: Using NVIDIA HW accelation encoder (nvenc), decoder (cuvid)
  - using -n and -c options
  ```sh
  $ FMembedder -i ~/demo/input.mp4 -o ~/demo/output.mp4 -n -c --access_key ACCESSKEY_BLAHBLAH
  ```

- Sample Mixer

  - Mandotory parameters:
    - You must keep the following parameters order.
    - Input media filename embedded with 0
      - e.g.) ~/demo/output_0.mp4
    - Input media filename embedded with 1
      - e.g.) ~/demo/output_1.mp4
    - Output media filename
      - e.g.) ~/demo/output_mix.mp4
    - 7-byte of user-specific-information
      - e.g.) testmsg or 746573746d7367
      - It supports 7 characters in ASCII or 14 characters in hexadecimal.
      - PallyCon cloud serveice supports up to 255-byte information. Please contact us for detailed information.
  - If you need some help about input parameters, run it without any option.
    ```sh
    $ sampleMixer
    ```

  Usage
  ```sh
  $ sampleMixer ~/demo/output_0.mp4 ~/demo/output_1.mp4 ~/demo/output_mix.mp4 testmsg
  ```
