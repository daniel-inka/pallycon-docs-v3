## Installing
Download the file and move it to the folder you unzipped.
### In Node.js
PallyCon token sample is to use the [npm](http://npmjs.org/) package manager for Node.js. Simply type the following into a terminal window:
<pre><code>
npm install
</code></pre>

## How to run
<pre><code>
npm run build
node app
</code></pre>

### Sample Information
File path : routes/tokenSample.js
