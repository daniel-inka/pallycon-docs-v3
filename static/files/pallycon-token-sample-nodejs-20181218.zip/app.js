const express = require('express');
const app = express();

const tokenRouter = require('./routes/tokenSample')

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use('/token', tokenRouter);


var port = 3000;
var server = app.listen(port, () =>{
    console.log("Express server has started on port " + server.address().port);
})
module.exports = app;