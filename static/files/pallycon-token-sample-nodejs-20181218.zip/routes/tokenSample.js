var express = require('express');
var pallyconToken = require('../dist/pallyconToken')
var router = express.Router();

/**
 * Required parameters in this sample
 * - userId, drmType, cid
 */
router.post('/', function(req, res, next) {
    /*--------------------------------------------------------------------------*/
    /*
    * ※ Notice
    * Set PallyCon site information.
    * https://console.pallycon.com
    * */
    var siteId = "";    // PallyCon site id
    var siteKey = '';   // PallyCon site Key
    var accessKey = ''; // PallyCon access Key
    /*--------------------------------------------------------------------------*/

    /*--------------------------------------------------------------------------*/
    /*
    * ※ Notice
    * Set token rule
    * https://docs.pallycon.com/en/multidrm/license/license-token/#token-data-json
    * */
    var token = {
        playback_policy: {
            limit: true,
            persistent: true,
            duration : 86400
        },
        security_policy: {
            output_protect: {
                control_hdcp: 0
            }
        }
    };
    /*--------------------------------------------------------------------------*/
    pallyconToken.setSiteInfo(siteId, siteKey, accessKey, function(err, data){
        if(err){
            console.log(err);
            return res.send(err.message);
        }
    });

    pallyconToken.makeToken(req.body.drmType, req.body.userId, req.body.cid, token, function (err, data){
        if(err){
            console.log(err);
            return res.send(err.message);
        }else{
            console.log(data);
            return res.send(data);
        }
    });
});

module.exports = router;