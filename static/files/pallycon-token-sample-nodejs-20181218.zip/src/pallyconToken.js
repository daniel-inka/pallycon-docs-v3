var crypto = require("crypto");

let AES_IV = '0123456789abcdef';
let siteInfo = {
    siteKey:'',
    siteId:'',
    accessKey:''
};
var util = {
    leadingZeros: (n, digits) => {
        var zero = '';
        n = n.toString();
        if (n.length < digits) {
            for (var i = 0; i < digits - n.length; i++)
                zero += '0';
        }
        return zero + n;
    },
    getUTCTime: (inputTime) => { // 24시간제
        let now;
        if (inputTime) {
            now = new Date(inputTime);
        } else {
            now = new Date();
        }
        var tz = now.getTime() + (now.getTimezoneOffset() * 60000);

        now.setTime(tz);
        var s = util.leadingZeros(now.getFullYear(), 4) + '-' +
            util.leadingZeros(now.getMonth() + 1, 2) + '-' +
            util.leadingZeros(now.getDate(), 2) + 'T' +
            util.leadingZeros(now.getHours(), 2) + ':' +
            util.leadingZeros(now.getMinutes(), 2) + ':' +
            util.leadingZeros(now.getSeconds(), 2) + "Z";
        return s;
    }
};
var pallyConToken = {
    setSiteInfo: (siteId='', siteKey='', accessKey='', callback) =>{
        var err = {};
        if( '' === siteId || '' === siteKey || '' === accessKey ){
            err.message = "There is a null value in the setSiteInfo input values.";
            callback(true, err);
        }else{
            siteInfo.siteId = siteId;
            siteInfo.siteKey = siteKey;
            siteInfo.accessKey = accessKey;
            callback(false, siteInfo);
        }
    },
    makeToken: (drmType='', userId='', cid='', plainTokenData='', callback) =>{
        var err = {};
        if( '' === drmType || '' === userId || '' === cid || '' === plainTokenData){
            err.message = 'There is a null value in the makeToken input values.';
            callback( err );
        }else{
            try{
                const currentTimeStamp = util.getUTCTime();
                console.log("currentTimeStamp : " + currentTimeStamp);
                let token = pallyConToken.aesEncrypt(JSON.stringify(plainTokenData));
                console.log('token : ' + token);
                let hashData = {
                    accessKey: siteInfo.accessKey,
                    drmType: drmType,
                    siteId: siteInfo.siteId,
                    userId: userId,
                    cid: cid,
                    token: token,
                    timestamp: currentTimeStamp
                };
                let hash = pallyConToken.makeHash(hashData);
                console.log('hash : ' + hash);
                let fullTokenData = {
                    drm_type: drmType,
                    site_id: siteInfo.siteId,
                    user_id: userId,
                    cid: cid,
                    token: token,
                    timestamp: currentTimeStamp,
                    hash: hash
                }
                var result = Buffer.from(JSON.stringify(fullTokenData)).toString('base64');
                console.log('result : ' + result);
                callback( false, result);
            }catch (err){
                console.log("err : " + err);
                callback(err);
            }
        }
    },
    makeHash: (hashData) => {
        const hash = hashData.accessKey
            + hashData.drmType
            + hashData.siteId
            + hashData.userId
            + hashData.cid
            + hashData.token
            + hashData.timestamp;
        let result = crypto.createHash('sha256').update(hash).digest('base64');
        return result;
    },
    aesDecrypt: (encData, aesIv = AES_IV) =>{
        const descipher = crypto.createDecipheriv('aes-256-cbc', siteInfo.siteKey, AES_IV);
        let result = descipher.update(encData, "base64", "utf-8");
        result += descipher.final("utf-8");

        return result;
    },
    aesEncrypt: (plainData, aesIv = AES_IV) =>{
        const cipher = crypto.createCipheriv('aes-256-cbc', siteInfo.siteKey, AES_IV);
        let result = cipher.update(plainData, "utf-8", "base64");
        result += cipher.final("base64");

        return result;
    }
};
module.exports = pallyConToken;
