# PallyCon Multi-DRM Bitmovin Encoder 연동 예제

이 예제 안내서는 CPIX 또는 SPEKE API를 통해 Bitmovin Encoder를 PallyCon Multi-DRM과 통합하는 방법을 설명합니다.

> 본 예제는 Bitmovin의 [CencDrmContentProtection](https://github.com/bitmovin/bitmovin-api-sdk-examples) 예제를 기반으로합니다.

## 준비 사항

- PallyCon Multi-DRM 서비스 계정 필요 (트라이얼 또는 상용 계정)
- Bitmovin Encoding 서비스 계정과 DRM integration API 권한 필요

## 방식 별 연동 설정

### 연동 방식 1 - PallyCon CPIX Module 사용

이 방식은 PallyCon에서 빌드한 Java 라이브러리 형태의 CPIX 모듈을 사용합니다.

먼저 Bitmovin 환경 구성에 아래 항목을 추가합니다.

```
//required
PALLYCON_ENC_TOKEN= {{PallyCon Console 에서 발급받은 kms 토큰}}
//required
PALLYCON_LICENSE_URL=https://license.pallycon.com/ri/licenseManager.do
//required
CONTENT_ID= {{ 패키징할 콘텐츠의 고유 ID }}
```

샘플 소스의 아래 함수들을 사용하여 연동을 설정합니다.

- DASH Widevine DRM: createDrmConfigCencDash 함수 사용  
- HLS FairPlay DRM: createDrmConfigFairPlay 함수 사용 

### 연동 방식 2 - SPEKE API 사용

이 방식은 PallyCon CPIX 모듈 대신 아래와 같은 SPEKE API를 사용합니다.

먼저 Bitmovin 환경 구성에 아래 항목을 추가합니다.

```
//required
PALLYCON_KMS_URL=https://kms.pallycon.com/cpix/getKey?enc-token=
//required
PALLYCON_ENC_TOKEN= {{PallyCon Console 에서 발급받은 kms 토큰}}
//required
CONTENT_ID= {{ 패키징할 콘텐츠의 고유 ID }}
// FairPlay Required
DRM_FAIRPLAY_IV = {{ PallyCon에서 정의한 IV값. 별도 문의로 요청 필요. }} 
```

샘플 소스의 아래 함수들을 사용하여 연동을 설정합니다.

- DASH Widevine DRM: createDrmConfigSpekeDash 함수 사용
- HLS FairPlay DRM: createDrmConfigSpekeHls 함수 사용

## 예제 실행 방법

### Linux

`src/main/java` 폴더의 java 소스 파일을 첫번째 매개 변수로 입력하여 아래와 같이 `run_example.sh` 파일을 실행합니다.

```bash
run-example.sh CencDrmContentProtectionByPallyCon BITMOVIN_API_KEY=your-api-key HTTP_INPUT_HOST=my-storage.biz
```

### Windows

`src/main/java` 폴더의 java 소스 파일을 첫번째 매개 변수로 입력하여 아래와 같이 `run_example.bat` 파일을 실행합니다.

```bash
run-example.bat CencDrmContentProtectionByPallyCon BITMOVIN_API_KEY=your-api-key HTTP_INPUT_HOST=my-storage.biz
```

***
