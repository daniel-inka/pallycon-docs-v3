var watermarkUtil = require('./watermark-util');
const config = require('./config.json');
let fwmModule;
if('aws' === config.type.toLowerCase()){
    //Used AWS MediaConvert Service
    fwmModule = require('./watermark-util/mediaConvertModule');
}else{
    //Used PallyCon Saas Service
    fwmModule = require('./watermark-util/pallyConModule');
}
'use strict';
const WATERMARK_FLAG_VALUE = 'dldzkdpsxmdnjrtm';

exports.handler = (event, context, callback) => {
    let request = event.Records[0].cf.request;
    console.log('request : ' + JSON.stringify(request));

    const arrUri = request.uri.split('/');
    const watermarkFlag = arrUri[1];
    if( WATERMARK_FLAG_VALUE === watermarkFlag ){
        //watermark content
        let watermarkData = arrUri[2];
        watermarkData = watermarkData.replace(/-/gi, '+');
        watermarkData = watermarkData.replace(/_/gi, '/');

        console.log("watermarkData = " + watermarkData);
        // watermarkdata format
        // {
        //      "watermark_data" : <watermark data>,
        //      "gop":60,
        //      "timestamp": < YYYY-mm-ddThh:mm:ssZ >
        // }
        const hintPath = request.uri.substr(arrUri[2].length + 1 + 17);
        let decWatermarkData = watermarkUtil.aesDecrypt(watermarkData, config.aesKey);
        console.log("decrypt WatermarkData : " + decWatermarkData);
        let watermarkInfo = JSON.parse(decWatermarkData);
        const watermark = new Buffer.from(watermarkInfo.watermark_data, 'base64').toString('hex');
        const timeStamp = watermarkInfo.timestamp;
        let gop = 60;
        // if( undefined !== watermarkInfo.gop){
        //     gop = watermarkInfo.gop;
        // }
        if(watermarkUtil.checkTimeStamp(timeStamp, config.availableInterval)){

            var response = fwmModule.createWatermarkUrl(hintPath, watermark, gop);
            console.log("response url : " + response);
            request.uri = response;
        }else{
            request = {status: '403'};
        }
    }

    callback(null, request);
}