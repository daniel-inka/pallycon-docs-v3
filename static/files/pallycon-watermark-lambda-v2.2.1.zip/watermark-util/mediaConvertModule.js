'use strict';

exports.createWatermarkUrl = (contentPath, watermark, gop=60) =>{
    let fileName, extension, trackIdx, wmFlag;
    let responseUrl = "/dldzkdpsxmdnjrtm";
    let waterInfo = {};
    let separator = contentPath.lastIndexOf('?');

    //파일이름시작index
    waterInfo.fileNameIdx = contentPath.lastIndexOf('/');
    //파라미터가 붙어있는 경우 파라미터를 분리 후 세팅
    if( -1 !== separator ){
        waterInfo.fileName = contentPath.substring(waterInfo.fileNameIdx+1, separator);
        waterInfo.parameter = contentPath.substring(separator);
    }else{
        //파일이름
        waterInfo.fileName = contentPath.substring(waterInfo.fileNameIdx+1);
        waterInfo.parameter = "";
    }

    waterInfo.extensionIdx = waterInfo.fileName.lastIndexOf('.');
    //확장자
    waterInfo.extension = waterInfo.fileName.substring(waterInfo.extensionIdx+1);

    switch(waterInfo.extension){
        case 'ts':
            //xxxxx.ts
            const fileIndex = Number(waterInfo.fileName.substring(waterInfo.fileName.lastIndexOf('_')+1, waterInfo.extensionIdx));
            wmFlag = makeWatermarkFlag(watermark, fileIndex, gop);
            responseUrl += makeDefaultPath(contentPath, 2, wmFlag);
            break;
        case 'mp4':
            //init.mp4
            if(-1 < waterInfo.fileName.lastIndexOf('init.mp4')){
                responseUrl += makeDefaultPath(contentPath, 2);
            }else{
                //xxxxxxx.mp4
                const fileIndex = Number(waterInfo.fileName.substring(waterInfo.fileName.lastIndexOf('_')+1, waterInfo.extensionIdx));
                wmFlag = makeWatermarkFlag(watermark, fileIndex, gop);
                responseUrl += makeDefaultPath(contentPath, 2, wmFlag);
            }
            break;
        default:
            responseUrl += makeDefaultPath(contentPath, 2);
            break;
    }
    responseUrl += waterInfo.parameter;

    return responseUrl;
}

const toWatermarkBinary = (str, gop) =>{
    var fullBin = '101100111';
    var result = '';
    // console.log('str', str);
    fullBin = fullBin + (Array
        .from(str)
        .reduce((acc, char) => acc.concat(parseInt(char, 16).toString(2)), [])
        .map(bin => '0'.repeat(4 - bin.length) + bin )
        .join(''));

    if( 60 === gop){
        result += fullBin;
    }else if( 30  === gop){
        for(var j=0; j<fullBin.length;j++){
            result += fullBin.charAt(j);
            result += fullBin.charAt(j);
        }
    }

    return result;
}
const makeWatermarkFlag = (watermark, tsNum, gop) => {
    let index = 0;
    const accCount = 60;
    const skipBit = 4;

    // 8 bits -> 2 hex characters
    let maxSkimTs = skipBit * (accCount / gop) + 1;
    console.log({watermark:watermark, tsNum: tsNum, gop:gop, maxSkimTs:maxSkimTs});
    if( 0 < tsNum && tsNum< maxSkimTs ){
        return '0';
    }else{
        let watermarkBin = toWatermarkBinary(watermark, gop);
        // 6.ts index 0  64
        tsNum = tsNum-maxSkimTs;
        index = tsNum % watermarkBin.length;
        return watermarkBin.charAt( index );
    }

}

const makeDefaultPath = (contentPath, seq, wm=0) => {
    var responseUrl = "";
    var pathArr = contentPath.split('/');
    var pathArrLength = pathArr.length;
    for(var i=1; i<pathArrLength; i++){
        if( i === (pathArrLength-seq) ){
            responseUrl += '/' + wm;
        }
        responseUrl += '/'+ pathArr[i];
    }
    return responseUrl;
}