'use strict';

exports.createWatermarkUrl = (contentPath, watermark, gop=60) =>{
    let fileName, extension, trackIdx, wmFlag;
    let responseUrl = "/dldzkdpsxmdnjrtm";
    let waterInfo = {};
    let separator = contentPath.lastIndexOf('?');

    //파일이름시작index
    waterInfo.fileNameIdx = contentPath.lastIndexOf('/');
    //파라미터가 붙어있는 경우 파라미터를 분리 후 세팅
    if( -1 !== separator ){
        waterInfo.fileName = contentPath.substring(waterInfo.fileNameIdx+1, separator);
        waterInfo.parameter = contentPath.substring(separator);
    }else{
        //파일이름
        waterInfo.fileName = contentPath.substring(waterInfo.fileNameIdx+1);
        waterInfo.parameter = "";
    }

    waterInfo.extensionIdx = waterInfo.fileName.lastIndexOf('.');
    //확장자
    waterInfo.extension = waterInfo.fileName.substring(waterInfo.extensionIdx+1);

    //폴더 경로
    var prefixPath = contentPath.substring(0, waterInfo.fileNameIdx);

    var prifixIdx = prefixPath.lastIndexOf('/');

    switch(waterInfo.extension){
        case 'mpd':
            responseUrl += makeDefaultPath(contentPath, 2);
            break;
        case 'm3u8':
            if( -1 < waterInfo.fileName.indexOf('master') ){
                responseUrl += makeDefaultPath(contentPath, 2);
            }else if( 'stream.m3u8' === waterInfo.fileName || 'iframes.m3u8' === waterInfo.fileName ){
                responseUrl += makeDefaultPath(contentPath, 5);
            }else if( 'subtitle.m3u8' === waterInfo.fileName ){
                responseUrl += makeDefaultPath(contentPath, 4);
            }else{
                responseUrl += makeDefaultPath(contentPath, 4);
            }
            break;
        case 'ts':
            const tsName = waterInfo.fileName.substring(0, waterInfo.extensionIdx);
            const arrTsName = tsName.split('segment-');

            wmFlag = makeWatermarkFlag(watermark, parseInt(arrTsName[1]), gop);
            responseUrl += makeDefaultPath(contentPath, 5, wmFlag);
            break;
        case 'm4s':
            if(checkSubtitle(prefixPath)){
                responseUrl += makeDefaultPath(contentPath, 4);
            }else{
                const m4sName = waterInfo.fileName.substring(0, waterInfo.extensionIdx);
                const arrM4sName = m4sName.split('seg-');
                wmFlag = makeWatermarkFlag(watermark, parseInt(arrM4sName[1]), gop);
                responseUrl += makeDefaultPath(contentPath, 5, wmFlag);
            }
            break;
        case 'mp4':
            if(checkSubtitle(prefixPath)){
                responseUrl += makeDefaultPath(contentPath, 4);
            }else{
                responseUrl += makeDefaultPath(contentPath, 5);
            }
            break;
        case 'vtt':
            responseUrl += makeDefaultPath(contentPath, 4);
            break;
        case "aac":
            responseUrl += makeDefaultPath(contentPath, 5);
            break;
        default:
            console.log("default!!");
            break;
    }
    responseUrl += waterInfo.parameter;

    return responseUrl;
}

const toWatermarkBinary = (str, gop) =>{
    var fullBin = '101100111';
    var result = '';
    // console.log('str', str);
    fullBin = fullBin + (Array
        .from(str)
        .reduce((acc, char) => acc.concat(parseInt(char, 16).toString(2)), [])
        .map(bin => '0'.repeat(4 - bin.length) + bin )
        .join(''));

    if( 60 === gop){
        result += fullBin;
    }else if( 30  === gop){
        for(var j=0; j<fullBin.length;j++){
            result += fullBin.charAt(j);
            result += fullBin.charAt(j);
        }
    }

    return result;
}
const makeWatermarkFlag = (watermark, tsNum, gop) => {
    let index = 0;
    const accCount = 60;
    const skipBit = 4;

    // 8 bits -> 2 hex characters
    let maxSkimTs = skipBit * (accCount / gop) + 1;
    console.log({watermark:watermark, tsNum: tsNum, gop:gop, maxSkimTs:maxSkimTs});
    if( 0 < tsNum && tsNum< maxSkimTs ){
        return '0';
    }else{
        console.log({watermark:watermark, tsNum: tsNum, gop:gop});
        let watermarkBin = toWatermarkBinary(watermark, gop);
        // 6.ts index 0  64
        tsNum = tsNum-maxSkimTs;
        index = tsNum % watermarkBin.length;
        return watermarkBin.charAt( index );
    }

}
const makeDefaultPath = (contentPath, seq, wm=0) => {
    var responseUrl = "";
    var pathArr = contentPath.split('/');
    var pathArrLength = pathArr.length;
    for(var i=1; i<pathArrLength; i++){
        if( i === (pathArrLength-seq) ){
            responseUrl += '/' + wm;
        }
        responseUrl += '/'+ pathArr[i];
    }
    return responseUrl;
}

const checkSubtitle = (prefixPath) =>{
    var boolSubtitle = false;
    let pathArr = prefixPath.split('/');
    let pathArrLength = pathArr.length;
    console.log("pathArr[pathArrLength-2] : " + pathArr[pathArrLength-2]);
    if( 'subtitle' === pathArr[pathArrLength-2]){
        boolSubtitle = true;
    }
    return boolSubtitle;
}