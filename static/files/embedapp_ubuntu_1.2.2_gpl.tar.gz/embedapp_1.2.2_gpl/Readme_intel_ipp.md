## Installation Intel® IPP 2018 Guide for Using APT Repository

- It is recommended to remove the already installed Intel® IPP library.

- Install the GPG key for the repository

```sh
$ sudo apt update
$ sudo apt install apt-transport-https
$ wget https://apt.repos.intel.com/intel-gpg-keys/GPG-PUB-KEY-INTEL-SW-PRODUCTS-2019.PUB
$ sudo apt-key add GPG-PUB-KEY-INTEL-SW-PRODUCTS-2019.PUB
```

- Add the Intel® IPP repository

```sh
$ sudo sh -c 'echo deb https://apt.repos.intel.com/ipp all main > /etc/apt/sources.list.d/intel-ipp.list'
```

- Update the list of the packages

```sh
$ sudo apt update
```

- Install IPP

```sh
$ sudo apt install intel-ipp-64bit-2018.3-051
```

- Uninstall IPP

```sh
$ sudo apt autoremove intel-ipp-64bit-2018.3-051
```


## Installation Intel® IPP 2018 Guide for Using YUM Repository

- It is recommended to remove the already installed Intel® IPP library.

- Add the repository

```sh
$ sudo yum install -y yum-utils
$ sudo yum-config-manager --add-repo https://yum.repos.intel.com/ipp/setup/intel-ipp.repo
```

- Import the gpg public key for the repository

```sh
$ sudo rpm --import https://yum.repos.intel.com/intel-gpg-keys/GPG-PUB-KEY-INTEL-SW-PRODUCTS-2019.PUB
```

- Install IPP

```sh
$ sudo yum install intel-ipp-64bit-2018.3-051
```

- Uninstall IPP

```sh
$ sudo yum autoremove intel-ipp-64bit-2018.3-051
```




## See also

- [Installing Intel® Performance Libraries and Intel® Distribution for Python* Using APT Repository](https://software.intel.com/en-us/articles/installing-intel-free-libs-and-python-apt-repo)

- [Installing Intel® Performance Libraries and Intel® Distribution for Python* Using YUM Repository](https://software.intel.com/en-us/articles/installing-intel-free-libs-and-python-yum-repo)

- [Free access to Intel® Compilers, Performance libraries, Analysis tools and more...](https://software.intel.com/en-us/articles/free-ipsxe-tools-and-libraries)