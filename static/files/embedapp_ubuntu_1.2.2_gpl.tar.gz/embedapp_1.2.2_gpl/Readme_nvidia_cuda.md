## Installation NVIDIA CUDA Toolkit 10.0

- Installation Instructions : Ubuntu 16.04

```sh
$ wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu1604/x86_64/cuda-repo-ubuntu1604_10.0.130-1_amd64.deb
$ sudo dpkg -i cuda-repo-ubuntu1604_10.0.130-1_amd64.deb
$ sudo apt-key adv --fetch-keys http://developer.download.nvidia.com/compute/cuda/repos/ubuntu1604/x86_64/7fa2af80.pub
$ sudo apt-get update
$ sudo apt-get install -y \
		linux-headers-$(uname -r) \
		cuda-9-1
```

- Installation Instructions : Centos 7

```sh
$ sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
$ wget https://developer.download.nvidia.com/compute/cuda/repos/rhel7/x86_64/cuda-repo-rhel7-10.0.130-1.x86_64.rpm
$ sudo rpm -i cuda-repo-rhel7-10.0.130-1.x86_64.rpm
$ sudo yum clean all
$ sudo yum install cuda-9-1
```

- Installation Instructions : AWS Linux2

```sh
```

## See also

- [NVIDIA CUDA Installation guide for Linux](http://developer.download.nvidia.com/compute/cuda/7.5/Prod/docs/sidebar/CUDA_Installation_Guide_Linux.pdf)

- [CUDA Toolkit 9.1 Download](https://developer.nvidia.com/cuda-91-download-archive?target_os=Linux&target_arch=x86_64&target_distro=Ubuntu&target_version=1604&target_type=debnetwork)

- [AWS, Installing the NVIDIA Driver on Linux Instances](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/install-nvidia-driver.html).