# PallyCon ASP Token Sample

## Quick Example

```asp
<!--
#Include File= "token/pallyConDrmTokenClient.asp" --><!--
#Include File= "token/policyRequest.asp" --><!--
#Include File= "token/playbackPolicyRequest.asp" --><!--
#Include File= "token/tokenBuilder.asp" --><!--
#Include File= "config.asp" --><%
Dim obj_drmTokenClient, obj_policyRequest
Dim result
on error resume next

` create token client
Set obj_drmTokenClient = new PallyConDrmTokenClient

' create token rule builder
Set obj_tokenBuilder = new TokenBuilder

' create playback policy rule
' https://pallycon.com/docs/en/multidrm/license/license-token/#playback-policy 
Set obj_playbackPolicyRequest = new PlaybackPolicyRequest
obj_playbackPolicyRequest.setLimit False
obj_playbackPolicyRequest.setDuration False

` build playback policy
` https://pallycon.com/docs/en/multidrm/license/license-token/#token-rule-json
obj_tokenBuilder.PlaybackPolicy(obj_playbackPolicyRequest)
Set obj_policyRequest = obj_tokenBuilder.Build

If Err.Number <> 0 Then
    Response.write "{""error_code"": """ & Err.Number &_
         """, ""error_message"": """ & Err.Source & " : " & Err.Description &"""}"
    Response.End
End If

' create license token
` siteId, accessKey, siteKey, userId, cid, policy are mandatory
` https://pallycon.com/docs/en/multidrm/license/license-token/#token-json-example
obj_drmTokenClient.Widevine
obj_drmTokenClient.SiteId(SITE_ID)
obj_drmTokenClient.AccessKey(SITE_KEY)
obj_drmTokenClient.SiteKey(ACCESS_KEY)
obj_drmTokenClient.UserId("testUser")
obj_drmTokenClient.Cid("test-cid")
obj_drmTokenClient.Policy(obj_policyRequest)

result = obj_drmTokenClient.Execute()

If Err.Number = 0 Then
    Response.Write result
Else
    Response.Write "{""error_code"": """ & Err.Number &_
     """, ""error_message"": """ & Err.Source & " : " & Err.Description &"""}"
End If
%>

```