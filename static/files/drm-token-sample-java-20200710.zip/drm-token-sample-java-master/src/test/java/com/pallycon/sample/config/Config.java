package com.pallycon.sample.config;

/**
 * needed to be set before compile
 */
public class Config {
    public static final String SITE_KEY = "<Site Key>";
    public static final String ACCESS_KEY = "<Access Key>";
    public static final String SITE_ID = "<Site ID>";
    public static final String USER_ID = "<tester-user>";
    public static final String C_ID = "<Content ID>";
}
